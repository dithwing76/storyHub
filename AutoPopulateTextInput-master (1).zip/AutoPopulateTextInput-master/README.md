# AutoPopulateTextInput
Tab Bar icons and auto-populate text
